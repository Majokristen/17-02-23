console.log("Entramos");

var items= document.getElementsByClassName("item");

var cantidad= items.length; 

console.log(cantidad);

console.log("Cantidad de listas" + cantidad);

var div=document.createElement("div");

div;
div.innerText= "Aprendiendo JavaScript";

var divUno= document.getElementById("uno");

divUno.appendChild(div);

var listas= document.getElementById("listas");

var hijo = document.createElement("li");
hijo.innerText = "li nuevo";
listas.appendChild(hijo);

document.getElementById("tres").style.color="red";
document.getElementById("listas").style.color="green";

var Cuerpo =document.getElementById("Cuerpo");
var div=document.createElement("div");
Cuerpo.appendChild(div);

var texto=document.createElement("p")

texto.innerText= "Quería' atención y yo te puse en el centro Quería' mi corazón y te lo puse en descuento Me pediste el cincuenta y yo te di 100% Me pediste un reloj y yo perdiendo mi tiempo Me quedé esperando que tu mensaje llegara Me comí otro cul, pero pensando en tu cara Quédate con la culpa y también con la ropa cara Y recuerda que la traición con traición se paga";
div.appendChild(texto);