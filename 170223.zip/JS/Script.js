 console.log("Hello Word")
var m=1;
var p=2;
var r= m+p;
console.log("Resultado:"+ r);


var k=1;
var n=2;
var r= k*n;
console.log("Resultado:"+ r);

var raiz=Math.sqrt(1244);
console.log("La raiz cuadrada de 1244 es: "+raiz);

var raiz2=Math.trunc(raiz);
console.log("Esto, aproximado al numero entero mas cercano, es igual a: "+raiz2);
    

    

